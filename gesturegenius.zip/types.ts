export interface Gesture {
  id: string;
  name: string;
  description: string;
  videoUrl?: string; // Object URL for preview
  timestamp: number;
}

export enum AppTab {
  LIBRARY = 'LIBRARY',
  LIVE = 'LIVE',
}

export interface ToolCall {
  functionCalls: {
    id: string;
    name: string;
    args: Record<string, any>;
  }[];
}
