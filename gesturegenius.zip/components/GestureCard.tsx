import React from 'react';
import { Gesture } from '../types';

interface GestureCardProps {
  gesture: Gesture;
  onDelete: (id: string) => void;
}

export const GestureCard: React.FC<GestureCardProps> = ({ gesture, onDelete }) => {
  return (
    <div className="bg-slate-800 rounded-xl overflow-hidden border border-slate-700 shadow-lg flex flex-col">
      <div className="relative aspect-video bg-black">
        {gesture.videoUrl && (
          <video 
            src={gesture.videoUrl} 
            className="w-full h-full object-cover opacity-80 hover:opacity-100 transition-opacity" 
            controls 
          />
        )}
        <div className="absolute top-2 right-2">
          <button 
            onClick={() => onDelete(gesture.id)}
            className="bg-red-500/20 hover:bg-red-500/40 text-red-200 p-1.5 rounded-full backdrop-blur-sm transition-colors"
            title="Delete Gesture"
          >
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4">
              <path strokeLinecap="round" strokeLinejoin="round" d="m14.74 9-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 0 1 3.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 0 0-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 0 0-7.5 0" />
            </svg>
          </button>
        </div>
      </div>
      <div className="p-4 flex-1 flex flex-col">
        <h3 className="text-lg font-bold text-white mb-1">{gesture.name}</h3>
        <div className="flex-1 overflow-y-auto max-h-32 mb-2 pr-1">
            <p className="text-xs text-slate-400 leading-relaxed">{gesture.description}</p>
        </div>
        <div className="pt-2 border-t border-slate-700 mt-auto">
            <span className="text-[10px] text-emerald-400 font-medium uppercase tracking-wider">Ready for Recognition</span>
        </div>
      </div>
    </div>
  );
};
