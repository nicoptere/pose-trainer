import React, { useState, useRef } from 'react';
import { Gesture } from '../types';
import { analyzeGestureVideo } from '../services/geminiService';
import { GestureCard } from './GestureCard';

interface LibraryTabProps {
  gestures: Gesture[];
  setGestures: React.Dispatch<React.SetStateAction<Gesture[]>>;
}

export const LibraryTab: React.FC<LibraryTabProps> = ({ gestures, setGestures }) => {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [newGestureName, setNewGestureName] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !newGestureName.trim()) {
      alert("Please enter a gesture name and select a video.");
      return;
    }

    // Basic validation
    if (file.size > 20 * 1024 * 1024) { // 20MB limit
      alert("Video file is too large. Please keep it under 20MB.");
      return;
    }

    setIsAnalyzing(true);
    try {
      const description = await analyzeGestureVideo(file, newGestureName);
      
      const newGesture: Gesture = {
        id: crypto.randomUUID(),
        name: newGestureName,
        description: description,
        videoUrl: URL.createObjectURL(file),
        timestamp: Date.now(),
      };

      setGestures(prev => [newGesture, ...prev]);
      setNewGestureName('');
      if (fileInputRef.current) fileInputRef.current.value = '';
    } catch (error) {
      console.error(error);
      alert("Failed to analyze video. Please try again.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleDelete = (id: string) => {
    setGestures(prev => prev.filter(g => g.id !== id));
  };

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Header / Upload Section */}
      <div className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700 backdrop-blur-sm">
        <div className="max-w-xl mx-auto text-center space-y-6">
          <div>
            <h2 className="text-2xl font-bold text-white mb-2">Teach New Gesture</h2>
            <p className="text-slate-400 text-sm">
              Upload a short video clip (2-5s) of a hand gesture. Gemini will analyze it and learn to recognize it in real-time.
            </p>
          </div>

          <div className="space-y-4 bg-slate-900/50 p-6 rounded-xl border border-slate-800">
            <div>
                <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2 text-left">Gesture Name</label>
                <input 
                type="text" 
                value={newGestureName}
                onChange={(e) => setNewGestureName(e.target.value)}
                placeholder="e.g., Thumbs Up, Peace Sign, Wave" 
                className="w-full bg-slate-800 text-white border border-slate-600 rounded-lg px-4 py-3 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all placeholder-slate-500"
                disabled={isAnalyzing}
                />
            </div>

            <div className="relative">
                <input 
                type="file" 
                ref={fileInputRef}
                accept="video/*"
                onChange={handleFileChange}
                className="hidden"
                id="video-upload"
                disabled={!newGestureName.trim() || isAnalyzing}
                />
                <label 
                htmlFor="video-upload"
                className={`flex items-center justify-center w-full px-6 py-4 border-2 border-dashed rounded-lg cursor-pointer transition-all ${
                    !newGestureName.trim() || isAnalyzing
                    ? 'border-slate-700 bg-slate-800/50 text-slate-500 cursor-not-allowed' 
                    : 'border-blue-500/50 bg-blue-500/10 text-blue-400 hover:bg-blue-500/20 hover:border-blue-500'
                }`}
                >
                {isAnalyzing ? (
                    <div className="flex items-center space-x-3">
                    <svg className="animate-spin h-5 w-5 text-blue-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    <span>Analyzing Video...</span>
                    </div>
                ) : (
                    <div className="flex items-center space-x-3">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6">
                        <path strokeLinecap="round" strokeLinejoin="round" d="m15.75 10.5 4.72-4.72a.75.75 0 0 1 1.28.53v11.38a.75.75 0 0 1-1.28.53l-4.72-4.72M4.5 18.75h9a2.25 2.25 0 0 0 2.25-2.25v-9a2.25 2.25 0 0 0-2.25-2.25h-9A2.25 2.25 0 0 0 2.25 7.5v9a2.25 2.25 0 0 0 2.25 2.25Z" />
                    </svg>
                    <span>{newGestureName.trim() ? "Select Video to Train" : "Enter Name First"}</span>
                    </div>
                )}
                </label>
            </div>
          </div>
        </div>
      </div>

      {/* Grid */}
      <div>
        <h3 className="text-xl font-semibold text-white mb-6 pl-1 flex items-center space-x-2">
            <span className="w-2 h-8 bg-blue-500 rounded-full inline-block"></span>
            <span>Trained Gestures ({gestures.length})</span>
        </h3>
        {gestures.length === 0 ? (
          <div className="text-center py-20 border border-dashed border-slate-700 rounded-2xl">
            <p className="text-slate-500">No gestures trained yet. Add one above to get started.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {gestures.map(gesture => (
              <GestureCard key={gesture.id} gesture={gesture} onDelete={handleDelete} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
