import React, { useRef, useState, useEffect } from 'react';
import { GoogleGenAI, LiveServerMessage } from '@google/genai';
import { Gesture } from '../types';
import { identifyGestureToolDeclaration } from '../services/geminiService';
import { pcmTo16BitBase64 } from '../services/utils';

interface LiveRecognizerTabProps {
  gestures: Gesture[];
}

export const LiveRecognizerTab: React.FC<LiveRecognizerTabProps> = ({ gestures }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [detectedGesture, setDetectedGesture] = useState<{ name: string; timestamp: number } | null>(null);
  const [debugLog, setDebugLog] = useState<string[]>([]);
  
  // Refs for cleanup
  const sessionRef = useRef<Promise<any> | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const intervalRef = useRef<number | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const processorRef = useRef<ScriptProcessorNode | null>(null);
  const sourceRef = useRef<MediaStreamAudioSourceNode | null>(null);

  const addLog = (msg: string) => {
    setDebugLog(prev => [msg, ...prev].slice(0, 10));
  };

  const startLiveSession = async () => {
    if (gestures.length === 0) {
      alert("Please train at least one gesture in the Library tab first.");
      return;
    }

    // Prevent multiple clicks
    if (isConnected || sessionRef.current) return;

    try {
      addLog("Initializing devices... (Please allow access)");
      
      // 1. Get Webcam & Microphone Stream
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { width: 640, height: 480 },
        audio: true 
      });
      
      streamRef.current = stream;
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }

      addLog("Devices active. Connecting to Gemini...");

      // 2. Initialize Gemini Live Client
      const apiKey = process.env.API_KEY;
      if (!apiKey) {
        addLog("Error: API_KEY is missing from environment.");
        throw new Error("API Key missing");
      }
      
      const ai = new GoogleGenAI({ apiKey });

      // 3. Build System Instruction
      const gestureDescriptions = gestures.map(g => `- Name: "${g.name}"\n  Description: ${g.description}`).join('\n');
      const systemInstruction = `
        You are an advanced real-time gesture recognition system.
        Your task is to watch the video stream and IDENTIFY if any of the following specific gestures are performed.
        
        KNOWN GESTURES:
        ${gestureDescriptions}

        INSTRUCTIONS:
        1. When you clearly see one of the KNOWN GESTURES performed, you MUST immediately call the 'identifyGesture' tool.
        2. Do not call the tool if the gesture is not clear or if it is a random movement.
        3. Only look for gestures in the list.
        4. Be responsive.
      `;

      // 4. Connect
      // Setup Audio Context
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      const audioContext = new AudioContextClass({ sampleRate: 16000 });
      audioContextRef.current = audioContext;

      // Note: We use string 'AUDIO' instead of Modality.AUDIO to avoid potential enum import issues in some builds
      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-09-2025',
        config: {
          responseModalities: ['AUDIO'], 
          systemInstruction: systemInstruction,
          tools: [{ functionDeclarations: [identifyGestureToolDeclaration] }],
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } }
          }
        },
        callbacks: {
          onopen: () => {
            addLog("Session Connected.");
            addLog("Ready to detect! Show me a gesture.");
            setIsConnected(true);
            
            // --- Audio Streaming Setup ---
            const source = audioContext.createMediaStreamSource(stream);
            const scriptProcessor = audioContext.createScriptProcessor(4096, 1, 1);
            
            scriptProcessor.onaudioprocess = (e) => {
              // Check if still connected to avoid errors after stop
              if (!sessionRef.current) return;

              const inputData = e.inputBuffer.getChannelData(0);
              const base64Audio = pcmTo16BitBase64(inputData);
              
              sessionPromise.then(session => {
                try {
                  session.sendRealtimeInput({
                    media: {
                      mimeType: 'audio/pcm;rate=16000',
                      data: base64Audio
                    }
                  });
                } catch (err) {
                  // Ignore send errors, likely session closed
                }
              });
            };

            source.connect(scriptProcessor);
            scriptProcessor.connect(audioContext.destination);
            
            sourceRef.current = source;
            processorRef.current = scriptProcessor;

            // --- Video Streaming Setup ---
            const canvas = canvasRef.current;
            const video = videoRef.current;
            if (!canvas || !video) return;
            const ctx = canvas.getContext('2d');

            // Send frames at ~2 FPS
            intervalRef.current = window.setInterval(() => {
                if (!sessionRef.current) return;

                if (video.readyState === 4 && ctx) {
                    canvas.width = video.videoWidth;
                    canvas.height = video.videoHeight;
                    ctx.drawImage(video, 0, 0);
                    
                    const base64Image = canvas.toDataURL('image/jpeg', 0.5).split(',')[1];
                    
                    sessionPromise.then(session => {
                        try {
                         session.sendRealtimeInput({
                            media: {
                                mimeType: 'image/jpeg',
                                data: base64Image
                            }
                         });
                        } catch (err) {
                            // Ignore send errors
                        }
                    });
                }
            }, 500); 
          },
          onmessage: (msg: LiveServerMessage) => {
            if (msg.toolCall) {
                addLog(`Tool called: ${msg.toolCall.functionCalls.length}`);
                for (const call of msg.toolCall.functionCalls) {
                    if (call.name === 'identifyGesture') {
                        const name = call.args['gestureName'];
                        const confidence = call.args['confidence'];
                        addLog(`GESTURE DETECTED: ${name} (${confidence || 'N/A'})`);
                        setDetectedGesture({ name, timestamp: Date.now() });
                        
                        sessionPromise.then(session => {
                            session.sendToolResponse({
                                functionResponses: {
                                    name: call.name,
                                    id: call.id,
                                    response: { result: "ok" }
                                }
                            });
                        });
                    }
                }
            }
          },
          onclose: () => {
            addLog("Session Closed by server.");
            setIsConnected(false);
            stopLiveSession();
          },
          onerror: (err) => {
            addLog(`Session Error: ${err.message || String(err)}`);
            console.error("Gemini Live Error:", err);
            stopLiveSession();
          }
        }
      });
      
      sessionRef.current = sessionPromise;

    } catch (e: any) {
      console.error(e);
      addLog(`Setup Failed: ${e.message}`);
      stopLiveSession();
    }
  };

  const stopLiveSession = () => {
    // Stop Intervals
    if (intervalRef.current) {
        window.clearInterval(intervalRef.current);
        intervalRef.current = null;
    }

    // Stop Audio Processing
    if (sourceRef.current) {
        try { sourceRef.current.disconnect(); } catch (e) {}
        sourceRef.current = null;
    }
    if (processorRef.current) {
         try { processorRef.current.disconnect(); } catch (e) {}
        processorRef.current = null;
    }
    if (audioContextRef.current) {
         try { audioContextRef.current.close(); } catch (e) {}
        audioContextRef.current = null;
    }

    // Stop Media Stream (Camera/Mic)
    if (streamRef.current) {
        streamRef.current.getTracks().forEach(track => track.stop());
        streamRef.current = null;
    }
    
    // Close Session
    if (sessionRef.current) {
        const currentSessionPromise = sessionRef.current;
        sessionRef.current = null; // Prevent further usage
        
        currentSessionPromise.then((session: any) => {
           try { session.close(); } catch(e) { console.log("Session already closed"); }
        }).catch(() => {
            // Ignore if promise rejected (connection failed)
        });
    }

    setIsConnected(false);
    addLog("Stopped.");
  };

  useEffect(() => {
    return () => {
        stopLiveSession();
    };
  }, []);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[calc(100vh-200px)] min-h-[500px]">
      {/* Video Feed Area */}
      <div className="lg:col-span-2 relative bg-black rounded-2xl overflow-hidden shadow-2xl border border-slate-700">
        <video 
          ref={videoRef} 
          className="absolute inset-0 w-full h-full object-cover" 
          muted 
          playsInline 
        />
        <canvas ref={canvasRef} className="hidden" />

        {/* Overlay UI */}
        <div className="absolute inset-0 pointer-events-none flex flex-col justify-between p-6">
            <div className="flex justify-between items-start">
                <div className="bg-black/60 backdrop-blur-md px-3 py-1.5 rounded-lg border border-white/10 flex items-center space-x-2">
                    <div className={`w-2.5 h-2.5 rounded-full ${isConnected ? 'bg-red-500 animate-pulse' : 'bg-slate-500'}`}></div>
                    <span className="text-xs font-mono text-white/90 uppercase tracking-widest">
                        {isConnected ? 'LIVE FEED' : 'OFFLINE'}
                    </span>
                </div>
                {detectedGesture && (Date.now() - detectedGesture.timestamp < 3000) && (
                    <div className="animate-bounce-in bg-gradient-to-r from-blue-600 to-indigo-600 text-white px-6 py-3 rounded-xl shadow-lg border border-blue-400/30 flex items-center space-x-3">
                        <span className="text-2xl">✨</span>
                        <div>
                            <p className="text-xs font-medium text-blue-200 uppercase tracking-wider">Detected</p>
                            <p className="text-xl font-bold">{detectedGesture.name}</p>
                        </div>
                    </div>
                )}
            </div>
            
            {/* Control Bar */}
            <div className="pointer-events-auto flex justify-center pb-4">
                {!isConnected ? (
                    <button 
                        onClick={startLiveSession}
                        disabled={!!sessionRef.current}
                        className="bg-emerald-500 hover:bg-emerald-600 disabled:opacity-50 disabled:cursor-not-allowed text-white px-8 py-3 rounded-full font-semibold shadow-lg shadow-emerald-500/20 transition-all flex items-center space-x-2"
                    >
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
                            <path fillRule="evenodd" d="M4.5 5.653c0-1.427 1.529-2.33 2.779-1.643l11.54 6.347c1.295.712 1.295 2.573 0 3.286L7.28 19.99c-1.25.687-2.779-.217-2.779-1.643V5.653Z" clipRule="evenodd" />
                        </svg>
                        <span>Start Recognition</span>
                    </button>
                ) : (
                    <button 
                        onClick={stopLiveSession}
                        className="bg-red-500 hover:bg-red-600 text-white px-8 py-3 rounded-full font-semibold shadow-lg shadow-red-500/20 transition-all flex items-center space-x-2"
                    >
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
                            <path fillRule="evenodd" d="M4.5 7.5a3 3 0 0 1 3-3h9a3 3 0 0 1 3 3v9a3 3 0 0 1-3 3h-9a3 3 0 0 1-3-3v-9Z" clipRule="evenodd" />
                        </svg>
                        <span>Stop</span>
                    </button>
                )}
            </div>
        </div>
      </div>

      {/* Sidebar Info */}
      <div className="bg-slate-800 rounded-2xl border border-slate-700 flex flex-col overflow-hidden">
        <div className="p-4 border-b border-slate-700 bg-slate-800/80">
            <h3 className="text-lg font-bold text-white">System Status</h3>
        </div>
        
        <div className="flex-1 p-4 overflow-y-auto space-y-4">
            <div>
                <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Active Gestures</h4>
                <div className="flex flex-wrap gap-2">
                    {gestures.map(g => (
                        <span key={g.id} className="bg-slate-700 text-slate-200 px-2 py-1 rounded text-xs border border-slate-600">
                            {g.name}
                        </span>
                    ))}
                </div>
            </div>

            <div>
                <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Debug Log</h4>
                <div className="bg-black/40 rounded-lg p-3 font-mono text-xs text-green-400 h-64 overflow-y-auto space-y-1">
                    {debugLog.map((log, i) => (
                        <div key={i} className="border-l-2 border-green-800 pl-2">
                            <span className="opacity-50 mr-2">{new Date().toLocaleTimeString()}</span>
                            {log}
                        </div>
                    ))}
                    {debugLog.length === 0 && <span className="text-slate-600 italic">Waiting for connection...</span>}
                </div>
            </div>
        </div>
      </div>
    </div>
  );
};
